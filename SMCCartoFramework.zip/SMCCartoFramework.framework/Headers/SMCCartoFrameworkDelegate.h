//
//  CartoFrameworkDelegate.h
//  CartoFramework
//
//  Created by Fernando Sanchez Vilas on 6/3/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
@class SITBuilding;
@class SITFloor;
@class SITPOI;

@protocol SMCCartoFrameworkDelegate <NSObject>
-(void)success;

-(void)activeBuilding:(SITBuilding *)building;
-(void)notActiveBuilding;

-(void)userSelectedBuilding:(SITBuilding *)building;
//TODO FER By now outdoor pois doesnt work
-(void)poiSelected:(SITPOI *)poi;
-(void)poiDeselected;

-(void)floorChanged:(SITFloor *)floor;
@end
