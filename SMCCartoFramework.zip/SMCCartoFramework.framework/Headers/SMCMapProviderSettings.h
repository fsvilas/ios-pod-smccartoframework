//
//  MapProviderSettings.h
//  CartoFramework
//
//  Created by Fernando Sanchez Vilas on 7/3/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, MapProviderType) {
    kGoogleMap,
    kAppleMap
};

@interface SMCMapProviderSettings : NSObject

//Camera settings are probably temporal? Use user location instead
@property (nonatomic,strong) NSNumber *cameraLatitude;
@property (nonatomic,strong) NSNumber *cameraLongitude;
@property (nonatomic,strong) NSNumber *cameraZoom;
@property (nonatomic,strong) NSString *apiKey;

@end
