//
//  SMCCartoFrameworkDataSource.h
//  SMCCartoFramework
//
//  Created by Fernando Sanchez Vilas on 24/5/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
@class SITBuildingInfo;
@class SITBuilding;

@protocol SMCCartoFrameworkDataSource <NSObject>

typedef void(^SMCCartoFrameworkFetchCompleteBuildingCallback) (SITBuildingInfo *buildingInfo);
- (void)completeInformationForBuilding:(SITBuilding *)building completionHandler:(SMCCartoFrameworkFetchCompleteBuildingCallback)completionHandler;
@end
