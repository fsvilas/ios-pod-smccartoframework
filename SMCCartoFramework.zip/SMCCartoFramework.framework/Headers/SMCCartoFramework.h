//
//  SMCCartoFramework.h
//  SMCCartoFramework
//
//  Created by Fernando Sanchez Vilas on 25/4/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SMCCartoFramework.
FOUNDATION_EXPORT double SMCCartoFrameworkVersionNumber;

//! Project version string for SMCCartoFramework.
FOUNDATION_EXPORT const unsigned char SMCCartoFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SMCCartoFramework/PublicHeader.h>


#import <SMCCartoFramework/SMCMapProviderSettings.h>
#import <SMCCartoFramework/SMCCartoFrameworkDelegate.h>
#import <SMCCartoFramework/SMCCartoFrameworkInterface.h>
#import <SMCCartoFramework/SMCCartoFrameworkFacade.h>
