//
//  SMCCartoFrameworkInterface.h
//  CartoFramework
//
//  Created by Fernando Sanchez Vilas on 17/4/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
@class SMCCartoFrameworkFacade;
@import UIKit;
#import "SMCCartoFrameworkDelegate.h"
#import "SMCCartoFrameworkDataSource.h"

@protocol SMCCartoFrameworkInterface <NSObject>
+(SMCCartoFrameworkFacade *)setupWithDelegate:(id<SMCCartoFrameworkDelegate>)delegate
                                   dataSource:(id<SMCCartoFrameworkDataSource>)dataSource parentViewController:(UIViewController *)parentViewController mapProviderType:(MapProviderType)mapProviderType settings:(SMCMapProviderSettings *)settings;
-(void)load;
-(void)unload;
- (void)setActiveBuilding:(SITBuilding *)building;
- (void)addBuildings:(NSArray <SITBuilding *>*)buildings;
- (SITBuilding *)activeBuilding;
- (SITFloor *)activeFloor;
@end
