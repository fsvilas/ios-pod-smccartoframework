//
//  CartoFrameworkFacade.h
//  CartoFramework
//
//  Created by Fernando Sanchez Vilas on 13/3/18.
//  Copyright © 2018 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SMCMapProviderSettings.h"
#import "SMCCartoFrameworkInterface.h"
@class SITBuilding;

@import UIKit;

@interface SMCCartoFrameworkFacade : NSObject<SMCCartoFrameworkInterface>



@end
